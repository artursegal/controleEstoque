<?php 

$conexao = mysqli_connect("localhost", "root", "", "controleEstoque");

 //$conexao = mysqli_connect("mysql.hostinger.com.br", "u157519637_cesto", "senha123", "u157519637_cesto");
<?php 
$titulo="Início";
include("cabecalho.php"); 

?>
<h1>Olá,</h1>

<p>Esse sistema foi desenvolvido para a Service como teste para Desenvolvedor Web.</p>

<p>Autor: Artur Segal Kaim</p><br>artursegal@gmail.com<br>(011) 97619-6510

<?php 
    include("rodape.php")
?>